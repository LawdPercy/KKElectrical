/* KK ELECTRICAL - ads.js: "Copy caption" buttons. Copies the caption text under an ad to the clipboard. */

document.querySelectorAll('.copy button').forEach(function(b){
  b.addEventListener('click',function(){
    var t=b.previousElementSibling.innerText;
    var done=function(){var o=b.textContent;b.textContent='Copied!';setTimeout(function(){b.textContent=o},1500)};
    if(navigator.clipboard){navigator.clipboard.writeText(t).then(done,done)}else{done()}
  });
});
