/* KK ELECTRICAL - main.js (menu, animation, WhatsApp form) */

/* 1. PHONE MENU: tapping the burger button opens/closes the menu; tapping a link closes it again */
var b=document.querySelector('.burger'),m=document.getElementById('menu');
b.addEventListener('click',function(){var o=m.classList.toggle('open');b.setAttribute('aria-expanded',o)});
m.addEventListener('click',function(e){if(e.target.tagName==='A'){m.classList.remove('open');b.setAttribute('aria-expanded',false)}});

/* 2. SCROLL ANIMATION: fades in every element with class "rv" as it scrolls into view.
      Older browsers without IntersectionObserver just show everything straight away. */
var els=document.querySelectorAll('.rv');
if('IntersectionObserver' in window){
  var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}})},{threshold:.12});
  els.forEach(function(e){io.observe(e)});
}else{els.forEach(function(e){e.classList.add('in')})}

/* 3. CONTACT FORM: builds a WhatsApp message from the form and opens WhatsApp.
      CHANGE THE NUMBER: replace 27721261704 (South Africa format, no + and no leading 0). */
document.getElementById('f').addEventListener('submit',function(e){
  e.preventDefault();
  var t='Hi KK Electrical, my name is '+document.getElementById('n').value+
    '. I need help with: '+document.getElementById('s').value+'.\n'+document.getElementById('m').value;
  window.open('https://wa.me/27721261704?text='+encodeURIComponent(t),'_blank');
});
