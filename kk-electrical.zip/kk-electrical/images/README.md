# Where to put your pictures

Save your photos in THIS folder (`images/`) using the exact file names below.
Names are lowercase and must end in `.jpg`. No photo yet? The site shows a blue
"Photo" placeholder, so nothing breaks.

Tip: resize photos before uploading (under 300 KB each is ideal) so the site loads fast on phones.
Free tools: squoosh.app or any photo editor. PNG/WebP also work if you rename the
file name inside `index.html` (search for the file name).

## Website (index.html)

| File name | Where it shows | Best size |
|---|---|---|
| `hero.jpg` | Big photo at the top of the page | 1200 x 1000 px, landscape |
| `power-tripping.jpg` | Service card: Power tripping | 1280 x 720 px (16:9) |
| `geyser.jpg` | Service card: Geyser not working | 1280 x 720 px (16:9) |
| `fault-finding.jpg` | Service card: Fault finding | 1280 x 720 px (16:9) |
| `house-wiring.jpg` | Service card: House wiring | 1280 x 720 px (16:9) |
| `coc.jpg` | Service card: COC | 1280 x 720 px (16:9) |
| `solar.jpg` | Service card: Basic solar system | 1280 x 720 px (16:9) |
| `team.jpg` | "Local, hands-on service" section | 1200 x 1000 px, landscape |
| `work-1.jpg` | Gallery: BIG featured photo | 1200 x 1200 px, square |
| `work-2.jpg` to `work-5.jpg` | Gallery: smaller photos | 800 x 800 px, square |
| `kenneth.jpg` | Round founder photo in About section | 600 x 600 px, square face photo |

## Ads (ads.html)

The ads reuse the service photos (`power-tripping.jpg`, `geyser.jpg`, `fault-finding.jpg`,
`house-wiring.jpg`, `coc.jpg`, `solar.jpg`) as a faint background. No extra files needed.

## Photo ideas

- Real photos of Kenneth's own jobs work best: a neat distribution board, a geyser being fitted, solar panels, a finished COC job.
- Only use photos you own or have permission to use. Customers' homes: ask first.
